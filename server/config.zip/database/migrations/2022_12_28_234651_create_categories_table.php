<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string("title");
            $table->unsignedInteger("price");
            $table->unsignedInteger("price_per_multiplied_kg")->nullable();
            $table->boolean("is_price_per_unit")->default(false);
            $table->boolean("is_price_per_set")->default(false);
            $table->enum("type", ["express", "instant", "normal"])->default("normal");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('categories');
    }
};

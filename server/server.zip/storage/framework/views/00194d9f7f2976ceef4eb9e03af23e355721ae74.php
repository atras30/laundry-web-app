<img src="<?php echo e(asset('qris.jpg')); ?>" alt="">
<?php /**PATH C:\Users\atras\Documents\Github\laundry-web-app\server\resources\views/welcome.blade.php ENDPATH**/ ?>